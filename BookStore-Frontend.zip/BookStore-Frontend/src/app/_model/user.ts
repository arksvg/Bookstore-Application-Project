export interface User {
  userName: string;
  userFirstName: string;
  userLastName: string;
  userPassword: string;
  email: string;
  mobile: number;
  address: string;
  role: any;
}
